-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2025 at 06:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate_applications`
--

CREATE TABLE `candidate_applications` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `running_position` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `submitted_at` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `profile_picture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidate_applications`
--

INSERT INTO `candidate_applications` (`id`, `username`, `full_name`, `running_position`, `age`, `sex`, `submitted_at`, `status`, `profile_picture`) VALUES
(15, 'zeeq', 'Zeed Jose', 'President', 24, 'Male', '2025-05-15 00:09:16', 'verified', 'assets/candidate_profiles\\zeeq.png'),
(16, 'janny', 'John Leonard Lopez', 'President', 25, 'Male', '2025-05-15 00:09:55', 'verified', 'assets/candidate_profiles\\janny.png'),
(17, 'Jeff', 'Jefrey Mark Dayep', 'Vice President', 22, 'Male', '2025-05-15 00:10:27', 'verified', 'assets/candidate_profiles\\Jeff.png'),
(18, 'missG', 'Bella Ramsey', 'President', 23, 'Female', '2025-05-15 00:11:43', 'verified', 'assets/candidate_profiles\\missG.png'),
(19, 'cailey', 'Cailey Spinach', 'Secretary', 23, 'Female', '2025-05-15 00:12:17', 'verified', 'assets/candidate_profiles\\cailey.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` date NOT NULL,
  `user_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `user_type`) VALUES
(18, 'Admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', '2025-05-15', 'admin'),
(19, 'Lester', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'student'),
(20, 'zeeq', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'candidate'),
(21, 'janny', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'candidate'),
(22, 'Jeff', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'candidate'),
(23, 'missG', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'candidate'),
(24, 'cailey', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'candidate'),
(25, 'Jasper', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2025-05-15', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `student_username` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `candidate_name` varchar(255) NOT NULL,
  `voted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `student_username`, `position`, `candidate_name`, `voted_at`) VALUES
(15, 'Lester', 'President', 'Bella Ramsey', '0000-00-00 00:00:00'),
(16, 'Lester', 'Secretary', 'Cailey Spinach', '0000-00-00 00:00:00'),
(17, 'Lester', 'Vice President', 'Jefrey Mark Dayep', '0000-00-00 00:00:00'),
(18, 'Jasper', 'President', 'Bella Ramsey', '0000-00-00 00:00:00'),
(19, 'Jasper', 'Secretary', 'Cailey Spinach', '0000-00-00 00:00:00'),
(20, 'Jasper', 'Vice President', 'Jefrey Mark Dayep', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate_applications`
--
ALTER TABLE `candidate_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate_applications`
--
ALTER TABLE `candidate_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
