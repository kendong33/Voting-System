import mysql.connector
from datetime import datetime
import hashlib

class DatabaseConnection:
    def __init__(self):
        self.connection = None
        self.cursor = None

    def connect(self):
        try:
            self.connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",  # Default XAMPP password is empty
                database="votingsystem"
            )
            self.cursor = self.connection.cursor(dictionary=True)  # Use dictionary cursor for easier data handling
            print("Successfully connected to the database!")
            return True
        except mysql.connector.Error as err:
            print(f"Error connecting to database: {err}")
            return False

    def register_user(self, username, password, user_type='student'):
        try:
            # Hash the password for security
            hashed_password = hashlib.sha256(password.encode()).hexdigest()
            
            # Prepare the SQL query
            query = """
                INSERT INTO users (username, password, user_type, created_at)
                VALUES (%s, %s, %s, %s)
            """
            values = (username, hashed_password, user_type, datetime.now())
            
            # Execute the query
            self.cursor.execute(query, values)
            self.connection.commit()
            
            # Get the auto-generated ID
            user_id = self.cursor.lastrowid
            print(f"User {username} registered successfully with ID: {user_id}!")
            return user_id
        except mysql.connector.Error as err:
            print(f"Error registering user: {err}")
            return None

    def get_user_by_id(self, user_id):
        try:
            query = "SELECT id, username, created_at FROM users WHERE id = %s"
            self.cursor.execute(query, (user_id,))
            return self.cursor.fetchone()
        except mysql.connector.Error as err:
            print(f"Error retrieving user: {err}")
            return None

    def get_user_by_username(self, username):
        try:
            query = "SELECT id, username, password, user_type, created_at FROM users WHERE username = %s"
            self.cursor.execute(query, (username,))
            return self.cursor.fetchone()
        except mysql.connector.Error as err:
            print(f"Error retrieving user: {err}")
            return None

    def verify_user(self, username, password):
        try:
            print(f"Verifying user: {username}")  # Debug log
            user = self.get_user_by_username(username)
            if user:
                print(f"User found in database with ID: {user['id']}")  # Debug log
                hashed_password = hashlib.sha256(password.encode()).hexdigest()
                if user['password'] == hashed_password:
                    print("Password verification successful")  # Debug log
                    return user['id']
                else:
                    print("Password verification failed")  # Debug log
            else:
                print(f"User not found: {username}")  # Debug log
            return None
        except mysql.connector.Error as err:
            print(f"Database error in verify_user: {err}")  # Debug log
            return None
        except Exception as e:
            print(f"Unexpected error in verify_user: {str(e)}")  # Debug log
            return None

    def close(self):
        if self.connection and self.connection.is_connected():
            self.cursor.close()
            self.connection.close()
            print("Database connection closed.")

    def insert_candidate_application(self, username, full_name, running_position, age, sex, profile_picture):
        try:
            query = """
                INSERT INTO candidate_applications (username, full_name, running_position, age, sex, status, submitted_at, profile_picture)
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), %s)
            """
            values = (username, full_name, running_position, age, sex, 'pending', profile_picture)
            self.cursor.execute(query, values)
            self.connection.commit()
            return True
        except Exception as err:
            print(f"Error inserting candidate application: {err}")
            return False

# Example usage
if __name__ == "__main__":
    db = DatabaseConnection()
    if db.connect():
        # Example registration
        user_id = db.register_user("test_user", "test_password")
        if user_id:
            print(f"Registered user with ID: {user_id}")
            # Example retrieval
            user = db.get_user_by_id(user_id)
            print(f"Retrieved user: {user}")
        db.close() 