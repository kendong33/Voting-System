# Color scheme
COLORS = {
    "primary": "#3498db",
    "secondary": "#2980b9",
    "accent": "#e74c3c",
    "success": "#2ecc71",
    "warning": "#f39c12",
    "light": "#ecf0f1",
    "dark": "#2c3e50",
    "text": "#333333",
    "white": "#ffffff"
}

# Font styles
FONTS = {
    "title": ("DM Serif Display", 72, "bold"),
    "subtitle": ("DM Serif Display", 18),
    "button": ("DM Serif Display", 16, "bold"),
    "small": ("DM Serif Display", 10),
    "nav": ("DM Serif Display", 12),
    "heading": ("DM Serif Display", 24, "bold"),
    "label": ("DM Serif Display", 12)
}

# Default user data
user_data = {
    "student": {"student123": "password123"},
    "candidate": {"candidate123": "password123"},
    "admin": {"admin123": "password123"}
}