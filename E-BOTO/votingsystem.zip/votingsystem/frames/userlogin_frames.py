import tkinter as tk
from tkinter import ttk, messagebox
from constants import COLORS, FONTS, user_data
import requests
import json
import mysql.connector
from datetime import datetime
import hashlib
from db_connection import DatabaseConnection


class UserLoginFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = DatabaseConnection()
        self.setup_ui()

    def setup_ui(self):
        self.configure(style="TFrame")

        login_container = ttk.Frame(self, style="TFrame")
        login_container.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(login_container, text="Login",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(pady=20)

        # Username and password fields
        self.username = tk.StringVar()
        self.password = tk.StringVar()

        form_frame = ttk.Frame(login_container, style="TFrame")
        form_frame.pack(pady=20)

        tk.Label(form_frame, text="Username:", bg=COLORS["light"],
                 fg=COLORS["text"], font=FONTS["label"]).grid(row=0, column=0, sticky="e", padx=10, pady=10)
        ttk.Entry(form_frame, textvariable=self.username, font=FONTS["label"]).grid(row=0, column=1, padx=10, pady=10,
                                                                                    ipadx=10, ipady=5)

        tk.Label(form_frame, text="Password:", bg=COLORS["light"],
                 fg=COLORS["text"], font=FONTS["label"]).grid(row=1, column=0, sticky="e", padx=10, pady=10)
        ttk.Entry(form_frame, textvariable=self.password, show="*",
                  font=FONTS["label"]).grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5)

        # Buttons
        btn_frame = ttk.Frame(login_container, style="TFrame")
        btn_frame.pack(pady=20)

        ttk.Button(btn_frame, text="Login", style="TButton",
                   command=self.login).pack(side="left", padx=10, ipadx=20)

        ttk.Button(btn_frame, text="Register", style="TButton",
                   command=lambda: self.controller.show_frame("UserRegisterFrame")).pack(side="left", padx=10,
                                                                                            ipadx=20)

        ttk.Button(login_container, text="Back", style="TButton",
                   command=lambda: self.controller.show_frame("MainFrame")).pack(pady=20)

    def clear_inputs(self):
        self.username.set('')
        self.password.set('')

    def login(self):
        username = self.username.get().strip()
        password = self.password.get()

        if not username or not password:
            messagebox.showerror("Login Failed", "Please enter both username and password.")
            return

        try:
            # Connect to database
            if not self.db.connect():
                messagebox.showerror("Login Failed", "Could not connect to database.")
                return

            # Get user and verify credentials
            user = self.db.get_user_by_username(username)
            if not user:
                messagebox.showerror("Login Failed", "Invalid username or password.")
                return

            # Verify password
            if not self.db.verify_user(username, password):
                messagebox.showerror("Login Failed", "Invalid username or password.")
                return

            # Login successful, redirect based on user type
            messagebox.showinfo("Login", "Login Successful!")
            
            # Get user type and redirect to appropriate dashboard
            user_type = user.get('user_type', '').lower()
            if user_type == 'student':
                # Pass the student's username to the dashboard
                self.controller.frames["StudentDashboardFrame"].set_student_username(username)
                self.controller.show_frame("StudentDashboardFrame")
            elif user_type == 'candidate':
                # Pass the candidate's username to the dashboard
                self.controller.frames["CandidateDashboardFrame"].set_candidate_username(username)
                self.controller.show_frame("CandidateDashboardFrame")
            elif user_type == 'admin':
                # Pass the admin's username to the dashboard
                self.controller.frames["AdminDashboardFrame"].set_admin_username(username)
                self.controller.show_frame("AdminDashboardFrame")
            else:
                messagebox.showerror("Login Failed", "Invalid user type.")
                return

            self.clear_inputs()

        except Exception as e:
            messagebox.showerror("Login Failed", f"An error occurred: {str(e)}")
        finally:
            self.db.close()


class UserRegisterFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = DatabaseConnection()
        self.setup_ui()

    def setup_ui(self):
        self.configure(style="TFrame")

        register_container = ttk.Frame(self, style="TFrame")
        register_container.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(register_container, text="Registration",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(pady=20)

        # Registration fields
        self.username = tk.StringVar()
        self.password = tk.StringVar()
        self.confirm_password = tk.StringVar()
        self.user_type = tk.StringVar(value="student")  # Default value

        form_frame = ttk.Frame(register_container, style="TFrame")
        form_frame.pack(pady=20)

        tk.Label(form_frame, text="Username:", bg=COLORS["light"],
                 fg=COLORS["text"], font=FONTS["label"]).grid(row=0, column=0, sticky="e", padx=10, pady=10)
        ttk.Entry(form_frame, textvariable=self.username, font=FONTS["label"]).grid(row=0, column=1, padx=10, pady=10,
                                                                                    ipadx=10, ipady=5)

        tk.Label(form_frame, text="Password:", bg=COLORS["light"],
                 fg=COLORS["text"], font=FONTS["label"]).grid(row=1, column=0, sticky="e", padx=10, pady=10)
        ttk.Entry(form_frame, textvariable=self.password, show="*",
                  font=FONTS["label"]).grid(row=1, column=1, padx=10, pady=10, ipadx=10, ipady=5)

        tk.Label(form_frame, text="Confirm Password:", bg=COLORS["light"],
                 fg=COLORS["text"], font=FONTS["label"]).grid(row=2, column=0, sticky="e", padx=10, pady=10)
        ttk.Entry(form_frame, textvariable=self.confirm_password, show="*",
                  font=FONTS["label"]).grid(row=2, column=1, padx=10, pady=10, ipadx=10, ipady=5)

        # User Type Dropdown
        tk.Label(form_frame, text="User Type:", bg=COLORS["light"],
                 fg=COLORS["text"], font=FONTS["label"]).grid(row=3, column=0, sticky="e", padx=10, pady=10)
        user_types = ["student", "candidate", "admin"]
        ttk.Combobox(form_frame, textvariable=self.user_type, values=user_types,
                     state="readonly", font=FONTS["label"]).grid(row=3, column=1, padx=10, pady=10, ipadx=10, ipady=5)

        # Buttons
        ttk.Button(register_container, text="Register", style="TButton",
                   command=self.register).pack(pady=20, ipadx=20)

        ttk.Button(register_container, text="Back", style="TButton",
                   command=lambda: self.controller.show_frame("UserLoginFrame")).pack(pady=20)

    def clear_inputs(self):
        self.username.set('')
        self.password.set('')
        self.confirm_password.set('')
        self.user_type.set('student')

    def register(self):
        username = self.username.get().strip()
        password = self.password.get()
        confirm_password = self.confirm_password.get()
        user_type = self.user_type.get()

        # Validate input
        if not username or not password or not confirm_password:
            messagebox.showerror("Registration Failed", "All fields are required.")
            return

        if len(username) < 3:
            messagebox.showerror("Registration Failed", "Username must be at least 3 characters long.")
            return

        # if len(password) < 8:
        #     messagebox.showerror("Registration Failed", "Password must be at least 8 characters long.")
        #     return

        if password != confirm_password:
            messagebox.showerror("Registration Failed", "Passwords do not match.")
            return

        try:
            # Connect to database
            if not self.db.connect():
                messagebox.showerror("Registration Failed", "Could not connect to database.")
                return

            # Check if username already exists
            existing_user = self.db.get_user_by_username(username)
            if existing_user:
                messagebox.showerror("Registration Failed", "Username already exists.")
                return

            # Register the user
            user_id = self.db.register_user(username, password, user_type)
            if user_id:
                messagebox.showinfo("Registration", f"{user_type.capitalize()} registered successfully!")
                self.controller.show_frame("UserLoginFrame")
                self.clear_inputs()
            else:
                messagebox.showerror("Registration Failed", "Failed to register user. Please try again.")

        except Exception as e:
            messagebox.showerror("Registration Failed", f"An error occurred: {str(e)}")
        finally:
            self.db.close()


class StudentDashboardFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.setup_ui()

    def setup_ui(self):
        self.configure(style="TFrame")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        tk.Label(header_frame, text=f"Welcome, Student!",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(side="left", padx=10)

        # Main menu frame
        menu_frame = ttk.Frame(self, style="TFrame")
        menu_frame.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Button(menu_frame, text="Cast a Vote", style="TButton",
                   command=lambda: self.controller.show_frame("CastVoteFrame")).pack(pady=20, ipadx=40, ipady=10)
        ttk.Button(menu_frame, text="Edit Profile", style="TButton",
                   command=self.edit_profile).pack(pady=20, ipadx=40, ipady=10)
        ttk.Button(menu_frame, text="Logout", style="TButton",
                   command=lambda: self.controller.show_frame("UserLoginFrame")).pack(pady=20, ipadx=40, ipady=10)

    def edit_profile(self):
        messagebox.showinfo("Edit Profile", "Edit Profile feature coming soon!")