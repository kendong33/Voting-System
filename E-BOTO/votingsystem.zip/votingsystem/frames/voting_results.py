import tkinter as tk
from tkinter import ttk, messagebox
from constants import COLORS, FONTS
from db_connection import DatabaseConnection
import os
from PIL import Image, ImageTk

class VotingResultsFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = DatabaseConnection()
        self.profile_images = {}
        self.setup_ui()
        self.load_results()

    def setup_ui(self):
        self.configure(style="TFrame")

        # Configure Treeview style for clean look
        style = ttk.Style()
        style.configure("VotingResults.Treeview",
            background=COLORS["white"],
            foreground=COLORS["dark"],
            rowheight=50,
            fieldbackground=COLORS["white"],
            borderwidth=0)
        style.configure("VotingResults.Treeview.Heading",
            background=COLORS["white"],
            foreground="black",
            font=FONTS["button"],
            relief="flat",
            padding=(8, 6))
        style.map("VotingResults.Treeview.Heading",
            background=[("active", COLORS["white"]), ("!active", COLORS["white"])],
            foreground=[("active", "black"), ("!active", "black")])
        style.map("VotingResults.Treeview",
            background=[("selected", COLORS["primary"])],
            foreground=[("selected", "white")])
        style.configure("VotingResults.Treeview.RowHover", background="#f0f0f0")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        tk.Label(header_frame, text="Voting Results",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(side="left", padx=10)
        # Add a frame to group Back and Refresh buttons
        btn_frame = tk.Frame(header_frame, bg=COLORS["light"])
        btn_frame.pack(side="right")
        ttk.Button(btn_frame, text="Back", style="Custom.TButton",
                   command=lambda: self.controller.show_frame("AdminDashboardFrame")).pack(side="right", padx=(10,0))
        ttk.Button(btn_frame, text="Refresh", style="Custom.TButton",
                   command=self.load_results).pack(side="right", padx=(0,10))

        # Main content
        content_frame = ttk.Frame(self, style="TFrame")
        content_frame.pack(expand=True, fill="both", padx=20, pady=20)

        # Treeview for results
        columns = ("Position", "Name", "Votes")
        self.tree = ttk.Treeview(content_frame, columns=columns, show="tree headings", height=50, style="VotingResults.Treeview")
        self.tree.heading("#0", text="Profile Picture")
        self.tree.column("#0", width=60, anchor="center")
        self.tree.heading("Position", text="Position")
        self.tree.column("Position", width=200, anchor="center")
        self.tree.heading("Name", text="Name")
        self.tree.column("Name", width=200, anchor="center")
        self.tree.heading("Votes", text="Votes")
        self.tree.column("Votes", width=80, anchor="center")
        self.tree.pack(expand=True, fill="both", side="left")

        # Add hover effect
        self.tree.bind('<Motion>', self.on_treeview_hover)
        self._last_hovered = None

        # Scrollbar
        scrollbar = ttk.Scrollbar(content_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

    def on_treeview_hover(self, event):
        rowid = self.tree.identify_row(event.y)
        if hasattr(self, '_last_hovered') and self._last_hovered and self._last_hovered != rowid:
            self.tree.item(self._last_hovered, tags=())
        if rowid:
            self.tree.item(rowid, tags=("rowhover",))
            self.tree.tag_configure("rowhover", background="#f0f0f0")
            self._last_hovered = rowid

    def load_results(self):
        # Clear previous items
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.profile_images = {}
        self._last_hovered = None
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            # Get all candidates and their vote counts, grouped by position
            query = """
                SELECT ca.full_name, ca.running_position, ca.profile_picture, COUNT(v.id) as vote_count
                FROM candidate_applications ca
                LEFT JOIN votes v ON ca.full_name = v.candidate_name AND ca.running_position = v.position
                WHERE ca.status = 'verified'
                GROUP BY ca.running_position, ca.full_name, ca.profile_picture
                ORDER BY ca.running_position, vote_count DESC, ca.full_name
            """
            self.db.cursor.execute(query)
            candidates = self.db.cursor.fetchall()
            for cand in candidates:
                img = None
                if cand['profile_picture'] and os.path.exists(cand['profile_picture']):
                    pil_img = Image.open(cand['profile_picture'])
                    pil_img.thumbnail((40, 40))
                    img = ImageTk.PhotoImage(pil_img)
                    self.profile_images[cand['full_name']] = img
                else:
                    default_path = os.path.join('assets', 'default_user.png')
                    if os.path.exists(default_path):
                        pil_img = Image.open(default_path)
                        pil_img.thumbnail((40, 40))
                        img = ImageTk.PhotoImage(pil_img)
                        self.profile_images[cand['full_name']] = img
                self.tree.insert("", "end", text="", image=img,
                                 values=(cand['running_position'], cand['full_name'], cand['vote_count']))
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load voting results: {str(e)}")
        finally:
            self.db.close() 