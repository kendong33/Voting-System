import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from constants import COLORS, FONTS
from db_connection import DatabaseConnection
from logout import LogoutManager
import os


class AdminDashboardFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = DatabaseConnection()
        self.logout_manager = LogoutManager()
        self.admin_username = "Admin"  # Default value
        self.setup_styles()
        self.profile_images = {}  # Store image references
        self.setup_ui()
        self.load_candidates()

    def setup_styles(self):
        # Configure ttk styles
        style = ttk.Style()
        
        # Configure Treeview style
        style.configure("Custom.Treeview",
            background=COLORS["light"],
            foreground=COLORS["dark"],
            rowheight=30,
            fieldbackground=COLORS["light"],
            borderwidth=0)
        
        # Configure Treeview Heading style with padding
        style.configure("Custom.Treeview.Heading",
            background="black",
            foreground="black",
            relief="flat",
            font=FONTS["button"],
            padding=(8, 6))  # (horizontal, vertical) padding
        
        # Ensure header text is always black (no hover effect)
        style.map("Custom.Treeview.Heading",
            background=[("active", "black"), ("!active", "black")],
            foreground=[("active", "black"), ("!active", "black")])
        
        # Configure Treeview selected item style
        style.map("Custom.Treeview",
            background=[("selected", COLORS["primary"])],
            foreground=[("selected", "white")])
        
        # Configure Button style for Refresh List
        style.configure("Refresh.TButton",
            padding=(20, 10),  # More horizontal and vertical padding
            font=FONTS["button"],
            background=COLORS["primary"],
            foreground="white",
            borderwidth=0,
            focusthickness=3,
            focuscolor=COLORS["primary"])
        style.map("Refresh.TButton",
            background=[("active", COLORS["primary"]), ("pressed", COLORS["primary"]), ("!active", COLORS["primary"])],
            foreground=[("active", "black"), ("pressed", "blue"), ("!active", "black")])

    def set_admin_username(self, username):
        """Set the admin username and update the welcome message"""
        self.admin_username = username
        # Update the welcome label if it exists
        if hasattr(self, 'welcome_label'):
            self.welcome_label.config(text=f"Welcome, {username}!")

    def setup_ui(self):
        self.configure(style="TFrame")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        self.welcome_label = tk.Label(header_frame, text=f"Welcome, {self.admin_username}!",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"])
        self.welcome_label.pack(side="left", padx=10)

        ttk.Button(header_frame, text="Logout", style="Custom.TButton",
                   command=self.logout).pack(side="right", padx=10)

        # Main content
        content_frame = ttk.Frame(self, style="TFrame")
        content_frame.pack(expand=True, fill="both", padx=20, pady=20)

        tk.Label(content_frame, text="Candidate List",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(pady=(0, 20))

        # --- SCROLLABLE CANVAS FOR CARDS ---
        canvas = tk.Canvas(content_frame, bg=COLORS["light"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(content_frame, orient="vertical", command=canvas.yview)
        self.cards_frame = ttk.Frame(canvas, style="TFrame")

        self.cards_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=self.cards_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Refresh button
        ttk.Button(content_frame, text="Refresh List", style="Refresh.TButton",
                   command=self.load_candidates).pack(pady=(0, 10), padx=40, anchor="w")
        # See All Users button
        ttk.Button(content_frame, text="See All Users", style="Refresh.TButton",
                   command=lambda: self.controller.show_frame("AllUserFrame")).pack(pady=(0, 10), padx=40, anchor="w")
        # Voting Results button
        ttk.Button(content_frame, text="Voting Results", style="Refresh.TButton",
                   command=lambda: self.controller.show_frame("VotingResultsFrame")).pack(pady=(0, 20), padx=40, anchor="w")

    def load_candidates(self):
        # Clear previous cards
        for widget in self.cards_frame.winfo_children():
            widget.destroy()
        self.profile_images = {}

        try:
            # Connect to database
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return

            # Get all candidates (include profile_picture)
            query = """
                SELECT u.username, ca.full_name, ca.running_position, ca.age, ca.sex, ca.submitted_at, ca.status, ca.profile_picture
                FROM users u
                JOIN candidate_applications ca ON u.username = ca.username
                WHERE u.user_type = 'candidate'
                ORDER BY ca.submitted_at DESC
            """
            self.db.cursor.execute(query)
            candidates = self.db.cursor.fetchall()

            for i, candidate in enumerate(candidates):
                card = tk.Frame(self.cards_frame, bg="white", bd=2, relief="groove")
                card.pack(fill="x", padx=10, pady=8, ipadx=8, ipady=8)

                # Profile image
                img = None
                if candidate['profile_picture'] and os.path.exists(candidate['profile_picture']):
                    pil_img = Image.open(candidate['profile_picture'])
                    pil_img.thumbnail((150, 150))
                    img = ImageTk.PhotoImage(pil_img)
                    self.profile_images[candidate['username']] = img
                else:
                    # Use default image
                    default_path = os.path.join('assets', 'default_user.png')
                    if os.path.exists(default_path):
                        pil_img = Image.open(default_path)
                        pil_img.thumbnail((150, 150))
                        img = ImageTk.PhotoImage(pil_img)
                        self.profile_images[candidate['username']] = img
                img_label = tk.Label(card, image=img, bg="white")
                img_label.image = img  # keep reference
                img_label.grid(row=0, column=0, rowspan=4, padx=10, pady=10, sticky="nw")

                # Username (bold)
                username_label = tk.Label(card, text=candidate['full_name'], font=FONTS["button"], bg="white", anchor="w")
                username_label.grid(row=0, column=1, sticky="w", padx=(0, 10), pady=(10, 0))

                # Position, Age, Sex in one line
                pos_age_sex = f"Position: {candidate['running_position']}    Age: {candidate['age']}    Sex: {candidate['sex']}"
                tk.Label(card, text=pos_age_sex, font=FONTS["label"], bg="white", anchor="w").grid(row=1, column=1, sticky="w", padx=(0, 10))

                # Submitted at (left), Status (right)
                submitted = f"Submitted at: {candidate['submitted_at'].strftime('%Y-%m-%d %H:%M:%S')}"
                status = f"Status: {'Verified' if candidate['status'] == 'verified' else 'Pending'}"
                tk.Label(card, text=submitted, font=FONTS["label"], bg="white", anchor="w").grid(row=2, column=1, sticky="w", padx=(0, 10))
                tk.Label(card, text=status, font=FONTS["label"], bg="white", anchor="e").grid(row=2, column=2, sticky="e", padx=(0, 10))

                # Buttons (side by side, bottom right)
                btn_frame = tk.Frame(card, bg="white")
                btn_frame.grid(row=3, column=2, sticky="e", padx=(0, 10), pady=(10, 10))
                verify_btn = ttk.Button(btn_frame, text="Verify", style="Custom.TButton",
                                        command=lambda c=candidate: self.verify_candidate_card(c))
                delete_btn = ttk.Button(btn_frame, text="Delete", style="Custom.TButton",
                                        command=lambda c=candidate: self.delete_candidate_card(c))
                verify_btn.pack(side="left", padx=(0, 5))
                delete_btn.pack(side="left")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load candidates: {str(e)}")
        finally:
            self.db.close()

    def verify_candidate_card(self, candidate):
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            query = "UPDATE candidate_applications SET status = 'verified' WHERE username = %s"
            self.db.cursor.execute(query, (candidate['username'],))
            self.db.connection.commit()
            messagebox.showinfo("Verified", f"Candidate {candidate['full_name']} (username: {candidate['username']}) has been verified.")
            self.load_candidates()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to verify candidate: {str(e)}")
        finally:
            self.db.close()

    def delete_candidate_card(self, candidate):
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            query = "DELETE FROM candidate_applications WHERE username = %s"
            self.db.cursor.execute(query, (candidate['username'],))
            self.db.connection.commit()
            if self.db.cursor.rowcount > 0:
                messagebox.showinfo("Success", f"Candidate application for {candidate['username']} has been deleted.")
                self.load_candidates()
            else:
                messagebox.showerror("Error", "Failed to delete candidate application.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete candidate application: {str(e)}")
        finally:
            self.db.close()

    def logout(self):
        """Handle admin logout using LogoutManager"""
        self.logout_manager.logout(self, self.controller, 'admin', self.admin_username)

    def __del__(self):
        """Cleanup when frame is destroyed"""
        if hasattr(self, 'db'):
            self.db.close()