import tkinter as tk
from tkinter import ttk
from constants import COLORS, FONTS

class AboutFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(style="TFrame")
        self.setup_ui()

    def setup_ui(self):
        self.configure(style="TFrame")

        # Main container fills the whole frame
        container = tk.Frame(self, bg=COLORS["dark"])
        container.pack(fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(2, weight=1)

        # Left: Vertical 'About' label
        left_frame = tk.Frame(container, bg=COLORS["dark"])
        left_frame.grid(row=0, column=0, sticky="nswe")
        canvas = tk.Canvas(left_frame, width=60, bg=COLORS["dark"], highlightthickness=0, bd=0)
        canvas.pack(fill="y", expand=True)
        canvas.create_text(30, 200, text="About", angle=90, font=("Georgia", 40, "bold"), fill=COLORS["white"])

        # Vertical separator
        sep = tk.Frame(container, bg=COLORS["white"], width=2)
        sep.grid(row=0, column=1, sticky="nswe")

        # Right: About text
        right_frame = tk.Frame(container, bg=COLORS["dark"])
        right_frame.grid(row=0, column=2, sticky="nsew", padx=(30, 0), pady=0)
        right_frame.grid_rowconfigure(0, weight=1)
        right_frame.grid_columnconfigure(0, weight=1)
        about_text = (
            "An online voting system that will replace the old ballot system or paper system. "
            "Over the time we have utilized the required technology in every sector to improve efficiency and save the extra resources. "
            "But the voting system is still very expensive and requires a bigger workforce. The system is slower and still not completely tamper proof. "
            "We bring the system that is safe, reliable and solve the modern issues like higher reachability of the booth, crowd free voting, inexpensive, faster results and others."
        )
        text_label = tk.Label(
            right_frame,
            text=about_text,
            font=("Georgia", 18),
            fg=COLORS["white"],
            bg=COLORS["dark"],
            wraplength=700,
            justify="center",
            anchor="center"
        )
        text_label.grid(row=0, column=0, sticky="nsew", padx=20, pady=40)

        # Back button at the bottom inside the main area
        back_btn = tk.Button(
            right_frame,
            text="Back",
            font=FONTS["button"],
            bg=COLORS["primary"],
            fg="white",
            command=lambda: self.controller.show_frame("MainFrame")
        )
        back_btn.grid(row=1, column=0, sticky="s", pady=30)
