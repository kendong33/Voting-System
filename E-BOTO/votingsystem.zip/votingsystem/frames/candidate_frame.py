import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
from constants import COLORS, FONTS
from logout import LogoutManager
import os
import shutil

class CandidateDashboardFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.logout_manager = LogoutManager()
        self.profile_pic_path = None
        self.profile_pic_preview = None
        self.setup_ui()

    def setup_ui(self):
        self.configure(style="TFrame")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        self.welcome_label = tk.Label(header_frame, text=f"Welcome, Candidate!",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"])
        self.welcome_label.pack(side="left", padx=10)

        ttk.Button(header_frame, text="Logout", style="TButton",
                   command=self.logout).pack(side="right", padx=10)

        # --- Add custom style for the submit button ---
        style = ttk.Style()
        style.configure("CandidateSubmit.TButton",
                        font=FONTS["button"],
                        padding=(20, 10),
                        background=COLORS["primary"],
                        foreground="white",
                        borderwidth=0)
        style.map("CandidateSubmit.TButton",
                  background=[("active", COLORS["primary"]), ("pressed", COLORS["primary"]), ("!active", COLORS["primary"])],
                  foreground=[("active", "black"), ("pressed", "black"), ("!active", "black")])

        # Application Form
        form_frame = ttk.Frame(self, style="TFrame")
        form_frame.pack(pady=40, anchor="center", expand=True)

        input_width = 30

        # Profile Picture Upload
        tk.Label(form_frame, text="Profile Picture:", font=FONTS["label"], bg=COLORS["light"], fg=COLORS["text"]).grid(row=0, column=0, sticky="e", padx=10, pady=10)
        pic_btn = ttk.Button(form_frame, text="Choose Image", command=self.choose_profile_picture)
        pic_btn.grid(row=0, column=1, padx=10, pady=10, sticky="w")
        self.pic_preview_label = tk.Label(form_frame, bg=COLORS["light"])
        self.pic_preview_label.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        # Full Name
        tk.Label(form_frame, text="Full Name:", font=FONTS["label"], bg=COLORS["light"], fg=COLORS["text"]).grid(row=2, column=0, sticky="e", padx=10, pady=10)
        self.fullname_var = tk.StringVar()
        fullname_entry = ttk.Entry(form_frame, textvariable=self.fullname_var, font=FONTS["label"], width=input_width)
        fullname_entry.grid(row=2, column=1, padx=10, pady=10, ipady=5)

        # Running Position
        tk.Label(form_frame, text="Running Position:", font=FONTS["label"], bg=COLORS["light"], fg=COLORS["text"]).grid(row=3, column=0, sticky="e", padx=10, pady=10)
        self.position_var = tk.StringVar()
        positions = [
            "President", "Vice President", "Secretary", "Treasurer", "Auditor", "Sgt at Arms", "PRO"
        ]
        position_combo = ttk.Combobox(form_frame, textvariable=self.position_var, values=positions, state="readonly", font=FONTS["label"], width=input_width)
        position_combo.grid(row=3, column=1, padx=10, pady=10, ipady=5)

        # Age
        tk.Label(form_frame, text="Age:", font=FONTS["label"], bg=COLORS["light"], fg=COLORS["text"]).grid(row=4, column=0, sticky="e", padx=10, pady=10)
        self.age_var = tk.StringVar()
        age_entry = ttk.Entry(form_frame, textvariable=self.age_var, font=FONTS["label"], width=input_width)
        age_entry.grid(row=4, column=1, padx=10, pady=10, ipady=5)

        # Sex
        tk.Label(form_frame, text="Sex:", font=FONTS["label"], bg=COLORS["light"], fg=COLORS["text"]).grid(row=5, column=0, sticky="e", padx=10, pady=10)
        self.sex_var = tk.StringVar()
        sex_combo = ttk.Combobox(form_frame, textvariable=self.sex_var, values=["Male", "Female", "Other"], state="readonly", font=FONTS["label"], width=input_width)
        sex_combo.grid(row=5, column=1, padx=10, pady=10, ipady=5)

        # Submit Button (centered)
        submit_btn = ttk.Button(form_frame, text="Submit Application", style="CandidateSubmit.TButton", command=self.submit_application)
        submit_btn.grid(row=6, column=0, columnspan=2, pady=30, ipadx=20, sticky="ew")
        form_frame.grid_columnconfigure(0, weight=1)
        form_frame.grid_columnconfigure(1, weight=1)

    def choose_profile_picture(self):
        filetypes = [
            ("Image files", "*.png *.jpg *.jpeg *.gif"),
            ("All files", "*.*")
        ]
        filepath = filedialog.askopenfilename(title="Select Profile Picture", filetypes=filetypes)
        if filepath:
            # Save a copy to assets/candidate_profiles/
            os.makedirs("assets/candidate_profiles", exist_ok=True)
            ext = os.path.splitext(filepath)[1]
            username = getattr(self, 'candidate_username', 'candidate')
            dest_path = os.path.join("assets/candidate_profiles", f"{username}{ext}")
            shutil.copy(filepath, dest_path)
            self.profile_pic_path = dest_path
            # Show preview
            img = Image.open(dest_path)
            img.thumbnail((100, 100))
            self.profile_pic_preview = ImageTk.PhotoImage(img)
            self.pic_preview_label.config(image=self.profile_pic_preview)

    def set_candidate_username(self, username):
        """Set the candidate username and update the welcome message"""
        self.candidate_username = username
        if hasattr(self, 'welcome_label'):
            self.welcome_label.config(text=f"Welcome, {username}!")

    def logout(self):
        """Handle candidate logout using LogoutManager"""
        self.logout_manager.logout(self, self.controller, 'candidate', getattr(self, 'candidate_username', 'Candidate'))

    def submit_application(self):
        fullname = self.fullname_var.get().strip()
        position = self.position_var.get().strip()
        age = self.age_var.get().strip()
        sex = self.sex_var.get().strip()
        if not fullname or not position or not age or not sex:
            messagebox.showerror("Error", "All fields are required.")
            return
        if not self.profile_pic_path:
            messagebox.showerror("Error", "Please upload a profile picture.")
            return
        try:
            from db_connection import DatabaseConnection
            db = DatabaseConnection()
            if not db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            username = getattr(self, 'candidate_username', None)
            if not username:
                messagebox.showerror("Error", "No candidate username found.")
                return
            # Check if application already exists
            db.cursor.execute("SELECT id FROM candidate_applications WHERE username = %s", (username,))
            if db.cursor.fetchone():
                messagebox.showerror("Error", "You have already submitted an application and is pending for verification. Please wait for admin action.")
                db.close()
                return
            if not age.isdigit():
                messagebox.showerror("Error", "Age must be a number.")
                db.close()
                return
            # Save profile_pic_path to DB (requires profile_picture column)
            success = db.insert_candidate_application(username, fullname, position, int(age), sex, self.profile_pic_path)
            if success:
                messagebox.showinfo("Application Submitted", "Your application has been submitted and is pending verification!")
                self.fullname_var.set("")
                self.position_var.set("")
                self.age_var.set("")
                self.sex_var.set("")
                self.profile_pic_path = None
                self.pic_preview_label.config(image="")
            else:
                messagebox.showerror("Error", "Failed to submit application. Check console for details.")
            db.close()
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Failed to submit application: {str(e)}")

    def __del__(self):
        """Cleanup when frame is destroyed"""
        pass  # Remove db cleanup if not used in this frame