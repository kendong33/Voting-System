import tkinter as tk
from tkinter import ttk, messagebox
from constants import COLORS, FONTS
from db_connection import DatabaseConnection
import os
from PIL import Image, ImageTk

class CastVoteFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = DatabaseConnection()
        self.student_username = None
        self.setup_ui()

    def set_student_username(self, username):
        self.student_username = username

    def setup_ui(self):
        self.configure(style="TFrame")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        tk.Label(header_frame, text="Cast Your Vote",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(side="left", padx=10)
        ttk.Button(header_frame, text="Back", style="TButton",
                   command=lambda: self.controller.show_frame("StudentDashboardFrame")).pack(side="right", padx=10)

        # Voting section with scrollable area
        self.voting_frame = ttk.Frame(self, style="TFrame")
        self.voting_frame.pack(expand=True, fill="both", padx=50, pady=20)

        # Scrollable canvas
        canvas = tk.Canvas(self.voting_frame, bg=COLORS["light"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.voting_frame, orient="vertical", command=canvas.yview)
        self.candidates_inner_frame = ttk.Frame(canvas, style="TFrame")
        self.candidates_inner_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.candidates_inner_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Refresh button
        ttk.Button(self.voting_frame, text="Refresh", style="TButton", command=self.load_verified_candidates).pack(pady=10)

        # Store selection variables for each position
        self.selected_candidates = {}  # position: tk.StringVar
        self.candidate_radio_buttons = []
        self.load_verified_candidates()

        # Submit Vote button
        ttk.Button(self.voting_frame, text="Submit Vote", style="TButton", command=self.submit_vote).pack(pady=20)

    def load_verified_candidates(self):
        for rb in getattr(self, 'candidate_radio_buttons', []):
            rb.destroy()
        self.candidate_radio_buttons = []
        if hasattr(self, 'no_candidates_label') and self.no_candidates_label:
            self.no_candidates_label.destroy()
            self.no_candidates_label = None
        if hasattr(self, 'position_headers'):
            for header in self.position_headers:
                header.destroy()
        self.position_headers = []
        self.selected_candidates = {}
        # Destroy all widgets in candidates_inner_frame to prevent duplication/whitespace
        for widget in self.candidates_inner_frame.winfo_children():
            widget.destroy()
        candidates_by_position = {}
        candidate_images = {}
        try:
            if self.db.connect():
                query = """
                    SELECT ca.full_name, ca.running_position, ca.profile_picture
                    FROM users u
                    JOIN candidate_applications ca ON u.username = ca.username
                    WHERE u.user_type = 'candidate' AND ca.status = 'verified'
                    ORDER BY ca.running_position, ca.full_name
                """
                self.db.cursor.execute(query)
                for row in self.db.cursor.fetchall():
                    pos = row['running_position']
                    if pos not in candidates_by_position:
                        candidates_by_position[pos] = []
                    candidates_by_position[pos].append(row)
                self.db.close()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load candidates: {str(e)}")
        self._profile_images = {}
        if candidates_by_position:
            for position, candidates in candidates_by_position.items():
                header = tk.Label(self.candidates_inner_frame, text=position,
                                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["accent"])
                header.pack(anchor='center', pady=(20, 5))
                self.position_headers.append(header)
                self.selected_candidates[position] = tk.StringVar()
                # Centered frame for cards
                center_frame = tk.Frame(self.candidates_inner_frame, bg=COLORS["light"])
                center_frame.pack(anchor="center")
                for candidate in candidates:
                    card_row = tk.Frame(center_frame, bg=COLORS["light"])
                    card_row.pack(anchor="center", pady=8)
                    # Radio button outside the card (left)
                    rb = ttk.Radiobutton(card_row, variable=self.selected_candidates[position],
                                         value=candidate['full_name'], style="TRadiobutton")
                    rb.pack(side='left', padx=(0, 10))
                    # Card
                    card = tk.Frame(card_row, bg="white", bd=2, relief="groove", width=300, height=200)
                    card.pack(side='left')
                    card.pack_propagate(False)
                    # Profile image
                    img = None
                    if candidate['profile_picture'] and os.path.exists(candidate['profile_picture']):
                        pil_img = Image.open(candidate['profile_picture'])
                        pil_img.thumbnail((100, 100))
                        img = ImageTk.PhotoImage(pil_img)
                        self._profile_images[candidate['full_name']] = img
                    else:
                        default_path = os.path.join('assets', 'default_user.png')
                        if os.path.exists(default_path):
                            pil_img = Image.open(default_path)
                            pil_img.thumbnail((100, 100))
                            img = ImageTk.PhotoImage(pil_img)
                            self._profile_images[candidate['full_name']] = img
                    if img:
                        img_label = tk.Label(card, image=img, bg="white")
                        img_label.image = img
                        img_label.pack(pady=(10, 5))
                    # Name
                    tk.Label(card, text=candidate['full_name'], font=FONTS["button"], bg="white").pack(pady=(0, 10))
                    self.candidate_radio_buttons.append(rb)
        else:
            self.no_candidates_label = tk.Label(self.candidates_inner_frame, text="No verified candidates available.",
                                                font=FONTS["label"], bg=COLORS["light"], fg=COLORS["text"])
            self.no_candidates_label.pack(pady=20)

    def submit_vote(self):
        votes = {pos: var.get() for pos, var in self.selected_candidates.items()}
        missing = [pos for pos, candidate in votes.items() if not candidate]
        if missing:
            messagebox.showwarning("Incomplete Vote", f"Please select a candidate for: {', '.join(missing)}.")
            return
        receipt = "You are about to cast your vote for:\n\n"
        for pos, candidate in votes.items():
            receipt += f"{pos}: {candidate}\n"
        receipt += "\nDo you want to confirm your vote?"
        if not messagebox.askyesno("Voting Receipt", receipt):
            return
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            username = self.student_username
            for position, candidate in votes.items():
                self.db.cursor.execute(
                    "SELECT id FROM votes WHERE student_username = %s AND position = %s",
                    (username, position)
                )
                if self.db.cursor.fetchone():
                    messagebox.showerror("Already Voted", f"You have already voted for {position}.")
                    self.db.close()
                    return
                self.db.cursor.execute(
                    "INSERT INTO votes (student_username, position, candidate_name) VALUES (%s, %s, %s)",
                    (username, position, candidate)
                )
            self.db.connection.commit()
            messagebox.showinfo("Vote Submitted", "Your vote has been submitted! Thank you for voting.")
            for var in self.selected_candidates.values():
                var.set("")
            self.db.close()
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Failed to submit vote: {str(e)}") 