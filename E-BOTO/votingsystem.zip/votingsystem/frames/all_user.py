import tkinter as tk
from tkinter import ttk, messagebox
from constants import COLORS, FONTS
from db_connection import DatabaseConnection
import os

class AllUserFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = DatabaseConnection()
        self.profile_images = {}
        self.setup_ui()
        self.load_users()

    def setup_ui(self):
        self.configure(style="TFrame")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        tk.Label(header_frame, text="All Users",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(pady=10, anchor="center", expand=True, fill="x")
        ttk.Button(header_frame, text="Back", style="Custom.TButton",
                   command=lambda: self.controller.show_frame("AdminDashboardFrame")).pack(side="right", padx=10)

        # Main content
        content_frame = ttk.Frame(self, style="TFrame")
        content_frame.pack(expand=True, fill="both", padx=20, pady=20)

        # --- SCROLLABLE CANVAS FOR CARDS ---
        canvas = tk.Canvas(content_frame, bg=COLORS["light"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(content_frame, orient="vertical", command=canvas.yview)
        self.cards_frame = ttk.Frame(canvas, style="TFrame")

        self.cards_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=self.cards_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def load_users(self):
        for widget in self.cards_frame.winfo_children():
            widget.destroy()
        self.profile_images = {}
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            query = """
                SELECT u.username, u.user_type, u.created_at, ca.profile_picture
                FROM users u
                LEFT JOIN candidate_applications ca ON u.username = ca.username
                ORDER BY u.user_type, u.created_at DESC
            """
            self.db.cursor.execute(query)
            users = self.db.cursor.fetchall()
            # Group users by user_type
            grouped = {"admin": [], "candidate": [], "student": []}
            for user in users:
                grouped.setdefault(user['user_type'], []).append(user)
            for user_type in ["admin", "candidate", "student"]:
                section = grouped.get(user_type, [])
                if section:
                    # User type header
                    header = tk.Label(self.cards_frame, text=user_type.capitalize(), font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["accent"])
                    header.pack(pady=(30, 10), anchor="center")
                    # Centered frame for cards
                    center_frame = tk.Frame(self.cards_frame, bg=COLORS["light"])
                    center_frame.pack(anchor="center")
                    for user in section:
                        card = tk.Frame(center_frame, bg="white", bd=2, relief="groove")
                        card.pack(padx=10, pady=8, ipadx=8, ipady=8, anchor="center")
                        # Profile image (if available)
                        img = None
                        if user.get('profile_picture') and os.path.exists(user['profile_picture']):
                            from PIL import Image, ImageTk
                            pil_img = Image.open(user['profile_picture'])
                            pil_img.thumbnail((100, 100))
                            img = ImageTk.PhotoImage(pil_img)
                            self.profile_images[user['username']] = img
                        else:
                            # Use default image
                            from PIL import Image, ImageTk
                            default_path = os.path.join('assets', 'default_user.png')
                            if os.path.exists(default_path):
                                pil_img = Image.open(default_path)
                                pil_img.thumbnail((100, 100))
                                img = ImageTk.PhotoImage(pil_img)
                                self.profile_images[user['username']] = img
                        if img:
                            img_label = tk.Label(card, image=img, bg="white")
                            img_label.image = img
                            img_label.pack(side="left", padx=10, pady=10)
                        info_frame = tk.Frame(card, bg="white")
                        info_frame.pack(side="left", padx=20)
                        tk.Label(info_frame, text=f"Username: {user['username']}", font=FONTS["button"], bg="white").pack(anchor="w")
                        tk.Label(info_frame, text=f"User Type: {user['user_type']}", font=FONTS["label"], bg="white").pack(anchor="w")
                        tk.Label(info_frame, text=f"Created At: {user['created_at'].strftime('%Y-%m-%d %H:%M:%S')}", font=FONTS["label"], bg="white").pack(anchor="w")
                        btn_frame = tk.Frame(card, bg="white")
                        btn_frame.pack(side="right", padx=20)
                        delete_btn = ttk.Button(btn_frame, text="Delete", style="Custom.TButton",
                                                command=lambda u=user: self.delete_user(u))
                        delete_btn.pack(side="top", pady=2)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load users: {str(e)}")
        finally:
            self.db.close()

    def delete_user(self, user):
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            query = "DELETE FROM users WHERE username = %s"
            self.db.cursor.execute(query, (user['username'],))
            self.db.connection.commit()
            if self.db.cursor.rowcount > 0:
                messagebox.showinfo("Success", f"User {user['username']} has been deleted.")
                self.load_users()
            else:
                messagebox.showerror("Error", "Failed to delete user.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete user: {str(e)}")
        finally:
            self.db.close() 