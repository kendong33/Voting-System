import tkinter as tk
from tkinter import ttk, messagebox
from constants import COLORS, FONTS
from logout import LogoutManager

class StudentDashboardFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.logout_manager = LogoutManager()
        self.student_username = None
        self.setup_ui()

    def set_student_username(self, username):
        self.student_username = username

    def setup_ui(self):
        self.configure(style="TFrame")

        # Header
        header_frame = ttk.Frame(self, style="TFrame")
        header_frame.pack(fill="x", padx=20, pady=10)

        tk.Label(header_frame, text=f"Welcome, Student!",
                 font=FONTS["heading"], bg=COLORS["light"], fg=COLORS["dark"]).pack(side="left", padx=10)

        # Main menu frame
        menu_frame = ttk.Frame(self, style="TFrame")
        menu_frame.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Button(menu_frame, text="Cast a Vote", style="TButton",
                   command=lambda: self.controller.show_frame("CastVoteFrame")).pack(pady=20, ipadx=40, ipady=10)
        ttk.Button(menu_frame, text="Edit Profile", style="TButton",
                   command=self.edit_profile).pack(pady=20, ipadx=40, ipady=10)
        ttk.Button(menu_frame, text="Logout", style="TButton",
                   command=self.logout).pack(pady=20, ipadx=40, ipady=10)

    def edit_profile(self):
        messagebox.showinfo("Edit Profile", "Edit Profile feature coming soon!")

    def logout(self):
        self.logout_manager.logout(self, self.controller, 'student', self.student_username)
