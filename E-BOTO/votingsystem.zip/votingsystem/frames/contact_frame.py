import tkinter as tk
from tkinter import ttk
from constants import COLORS, FONTS

class ContactFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(style="TFrame")
        self.setup_ui()

    def setup_ui(self):
        tk.Label(self, text="Contact", font=FONTS["title"],
                 bg=COLORS["light"], fg=COLORS["dark"]).pack(pady=20)

        contact_text = (
            "An online voting system that will replace the old ballot system.\n"
            "This project allows students to vote electronically with better accessibility,\n"
            "transparency, and efficiency while ensuring security and integrity."
        )

        tk.Label(self, text=contact_text, font=("Georgia", 12),
                 fg=COLORS["text"], bg=COLORS["light"], wraplength=600, justify="left").pack(pady=20)

        tk.Button(self, text="Back", font=FONTS["button"],
                  bg=COLORS["primary"], fg="white",
                  command=lambda: self.controller.show_frame("MainFrame")).pack(pady=10)
