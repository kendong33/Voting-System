import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import os
import sys
sys.path.append("..")
from constants import COLORS, FONTS


class MainFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.setup_ui()

    def setup_ui(self):
        self.configure(style="TFrame")

        # Navigation bar
        nav_bar = tk.Frame(self, bg=COLORS["light"])
        nav_bar.place(relwidth=1, height=50)

        # Navigation buttons
        btn_about = tk.Button(nav_bar, text="About", font=FONTS["nav"],
                              bg=COLORS["light"], fg=COLORS["dark"], bd=0,
                              command=self.show_about)
        btn_about.pack(side="right", padx=20)

        btn_contact = tk.Button(nav_bar, text="Contact", font=FONTS["nav"],
                                bg=COLORS["light"], fg=COLORS["dark"], bd=0)
        btn_contact.pack(side="right", padx=10)

        # btn_login = tk.Button(nav_bar, text="Login", font=FONTS["nav"],
        #               bg=COLORS["primary"], fg="white", bd=0,
        #               command=lambda: self.controller.show_frame("UserLoginFrame"))
        # btn_login.pack(side="right", padx=20)

        btn_login = tk.Button(nav_bar, text="Login", font=FONTS["button"],
                      bg=nav_bar["bg"],  # match background of parent to simulate transparency
                      fg=COLORS["primary"],  # blue text
                      activebackground="#1d6fa5",
                      activeforeground=COLORS["white"],
                      bd=0,
                      command=lambda: self.controller.show_frame("UserLoginFrame"))

        # Hover effects
        def on_enter(e):
            btn_login.config(bg="#1d6fa5", fg=COLORS["white"])  # solid blue background on hover

        def on_leave(e):
            btn_login.config(bg=nav_bar["bg"], fg=COLORS["primary"])  # back to simulated transparent

        btn_login.bind("<Enter>", on_enter)
        btn_login.bind("<Leave>", on_leave)

        btn_login.pack(side="right", padx=20)

        # Main content
        main_content = tk.Frame(self, bg=COLORS["light"])
        main_content.place(relx=0.5, rely=0.5, anchor="center")

        # Title and buttons
        # tk.Label(main_content, text="E BOTO", font=FONTS["title"],
        #          bg=COLORS["light"], fg=COLORS["dark"]).pack(pady=(0, 20))
        
        # Load and display logo
        logo_path = os.path.join("assets", "EBOTO LOGO1.png")
        logo_img = Image.open(logo_path)
        # Resize logo to appropriate size (adjust width as needed)
        logo_img = logo_img.resize((400, 200), Image.Resampling.LANCZOS)
        self.logo_photo = ImageTk.PhotoImage(logo_img)
        logo_label = tk.Label(main_content, image=self.logo_photo, bg=COLORS["light"])
        logo_label.pack(pady=(0, 20))

        tk.Label(main_content, text="Be a part of decision for our department",
                 font=FONTS["subtitle"], bg=COLORS["light"], fg=COLORS["text"]).pack(pady=(0, 40))

        tk.Button(main_content, text="Vote Today", font=FONTS["button"],
                  bg=COLORS["primary"], fg="white",
                  command=lambda: self.controller.show_frame("UserLoginFrame")).pack()

    def show_about(self):
        self.controller.show_frame("AboutFrame")