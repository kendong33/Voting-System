import tkinter as tk
from tkinter import messagebox
from db_connection import DatabaseConnection

class LogoutManager:
    def __init__(self):
        self.db = DatabaseConnection()

    def logout(self, frame, controller, user_type, username=""):
        """
        Handle user logout for all user types
        
        Args:
            frame: The current frame instance
            controller: The main application controller
            user_type: Type of user ('student', 'candidate', 'admin')
            username: Username of the logged-in user (optional)
        """
        try:
            # Clear session data based on user type
            if user_type == 'student':
                self._clear_student_session(frame)
            elif user_type == 'candidate':
                self._clear_candidate_session(frame)
            elif user_type == 'admin':
                self._clear_admin_session(frame)

            # Log the logout event
            self._log_logout_event(username, user_type)

            # Show logout message
            messagebox.showinfo("Logout", "You have been successfully logged out.")

            # Switch to login frame
            controller.show_frame("UserLoginFrame")

        except Exception as e:
            messagebox.showerror("Logout Error", f"An error occurred during logout: {str(e)}")
        finally:
            # Close database connection
            if hasattr(self, 'db'):
                self.db.close()

    def _clear_student_session(self, frame):
        """Clear student-specific session data"""
        if hasattr(frame, 'selected_candidate'):
            frame.selected_candidate.set("")

    def _clear_candidate_session(self, frame):
        """Clear candidate-specific session data"""
        if hasattr(frame, 'candidate_username'):
            frame.candidate_username = "Candidate"
        if hasattr(frame, 'welcome_label'):
            frame.welcome_label.config(text="Welcome, Candidate!")

    def _clear_admin_session(self, frame):
        """Clear admin-specific session data"""
        if hasattr(frame, 'admin_username'):
            frame.admin_username = "Admin"
        if hasattr(frame, 'welcome_label'):
            frame.welcome_label.config(text="Welcome, Admin!")
        if hasattr(frame, 'candidate_tree'):
            for item in frame.candidate_tree.get_children():
                frame.candidate_tree.delete(item)

    def _log_logout_event(self, username, user_type):
        """Log the logout event to the database"""
        try:
            if not self.db.connect():
                return

            query = """
                INSERT INTO user_logs (username, user_type, action, timestamp)
                VALUES (%s, %s, %s, NOW())
            """
            self.db.cursor.execute(query, (username, user_type, 'logout'))
            self.db.connection.commit()

        except Exception as e:
            print(f"Error logging logout event: {str(e)}")
        finally:
            if self.db.connection and self.db.connection.is_connected():
                self.db.close()

    def __del__(self):
        """Cleanup when the manager is destroyed"""
        if hasattr(self, 'db'):
            self.db.close() 