import tkinter as tk
from tkinter import ttk
from frames.main_frame import MainFrame
from frames.about_frame import AboutFrame
from frames.contact_frame import ContactFrame
# from frames.login_frame import LoginFrame
from frames.userlogin_frames import UserLoginFrame,UserRegisterFrame
from frames.student_frame import StudentDashboardFrame
from frames.candidate_frame import CandidateDashboardFrame
# from frames.candidate_frames import CandidateLoginFrame, CandidateRegisterFrame
from frames.admin_frames import AdminDashboardFrame
from frames.cast_vote import CastVoteFrame
from frames.all_user import AllUserFrame
from frames.voting_results import VotingResultsFrame
from constants import COLORS
import tkinter.messagebox as messagebox


class StudentVotingSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Voting System")
        self.root.geometry("1400x700")
        self.root.configure(bg="#f0f2f5")
        
        # Center the window on the screen
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        window_width = 1400
        window_height = 720
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        # Initialize frames
        self.frames = {}
        self.setup_frames()
        self.show_frame("MainFrame")

    def setup_frames(self):
        # Create all frames
        self.frames["MainFrame"] = MainFrame(self.root, self)
        # self.frames["LoginFrame"] = LoginFrame(self.root, self)
        self.frames["UserLoginFrame"] = UserLoginFrame(self.root, self)
        self.frames["UserRegisterFrame"] = UserRegisterFrame(self.root, self)
        self.frames["StudentDashboardFrame"] = StudentDashboardFrame(self.root, self)
        self.frames["CandidateDashboardFrame"] = CandidateDashboardFrame(self.root, self)
        # self.frames["CandidateLoginFrame"] = CandidateLoginFrame(self.root, self)
        # self.frames["CandidateRegisterFrame"] = CandidateRegisterFrame(self.root, self)
        # self.frames["AdminLoginFrame"] = AdminLoginFrame(self.root, self)
        self.frames["AdminDashboardFrame"] = AdminDashboardFrame(self.root, self)
        self.frames["AllUserFrame"] = AllUserFrame(self.root, self)
        self.frames["VotingResultsFrame"] = VotingResultsFrame(self.root, self)
        self.frames["AboutFrame"] = AboutFrame(self.root, self)
        self.frames["ContactFrame"] = ContactFrame(self.root, self)
        self.frames["CastVoteFrame"] = CastVoteFrame(self.root, self)

        # Hide all frames initially
        for frame in self.frames.values():
            frame.place_forget()

    def show_frame(self, frame_name):
        # Hide all frames
        for frame in self.frames.values():
            frame.place_forget()
        # Special handling: pass username to CastVoteFrame if needed
        if frame_name == "CastVoteFrame":
            student_frame = self.frames["StudentDashboardFrame"]
            username = getattr(student_frame, 'student_username', None)
            if username:
                self.frames["CastVoteFrame"].set_student_username(username)
        self.frames[frame_name].place(relwidth=1, relheight=1)

    def submit_vote(self):
        # Collect votes for each position
        votes = {pos: var.get() for pos, var in self.selected_candidates.items()}
        missing = [pos for pos, candidate in votes.items() if not candidate]
        if missing:
            messagebox.showwarning("Incomplete Vote", f"Please select a candidate for: {', '.join(missing)}.")
            return
        # Show voting receipt for confirmation
        receipt = "You are about to cast your vote for:\n\n"
        for pos, candidate in votes.items():
            receipt += f"{pos}: {candidate}\n"
        receipt += "\nDo you want to confirm your vote?"
        if not messagebox.askyesno("Voting Receipt", receipt):
            return

        # Save votes to the database
        try:
            if not self.db.connect():
                messagebox.showerror("Error", "Could not connect to database.")
                return
            username = self.student_username
            for position, candidate in votes.items():
                # Prevent double voting for the same position
                self.db.cursor.execute(
                    "SELECT id FROM votes WHERE student_username = %s AND position = %s",
                    (username, position)
                )
                if self.db.cursor.fetchone():
                    messagebox.showerror("Already Voted", f"You have already voted for {position}.")
                    self.db.close()
                    return
                self.db.cursor.execute(
                    "INSERT INTO votes (student_username, position, candidate_name) VALUES (%s, %s, %s)",
                    (username, position, candidate)
                )
            self.db.connection.commit()
            messagebox.showinfo("Vote Submitted", "Your vote has been submitted! Thank you for voting.")
            # Optionally, clear selections
            for var in self.selected_candidates.values():
                var.set("")
            self.db.close()
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Failed to submit vote: {str(e)}")


if __name__ == "__main__":
    root = tk.Tk()
    app = StudentVotingSystem(root)
    root.mainloop()